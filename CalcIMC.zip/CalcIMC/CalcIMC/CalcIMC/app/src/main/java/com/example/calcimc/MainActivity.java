package com.example.calcimc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edPeso, edAltura;
    Button btnCalc;
    Double peso, altura;
    String imc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edPeso = findViewById(R.id.editTextPeso);
        edAltura = findViewById(R.id.editTextAltura);
        btnCalc = findViewById(R.id.btnCalcular);
    }

    public void calc(View view) {
        peso = Double.parseDouble(edPeso.getText().toString());
        altura = Double.parseDouble(edAltura.getText().toString());
        imc = String.valueOf(peso / (altura * altura));
        Intent ResultIMC = new Intent(this, Resultado.class);
        ResultIMC.putExtra("ResultadoIMC", imc);
        startActivity(ResultIMC);
    }

}
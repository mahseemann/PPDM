package com.example.calcimc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Resultado extends AppCompatActivity {

    TextView ResultadoImc;
    ImageView imageView;
    String imc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);
        ResultadoImc = findViewById(R.id.txtReultado);
        imageView = findViewById(R.id.imageView);

        Intent a = getIntent();
        imc = a.getStringExtra("ResultadoIMC");
        ResultadoImc.setText(String.valueOf(imc));
        IMC();
    }
    public void IMC () {
        double imcDouble = Double.parseDouble(imc);
        if (imcDouble < 18.5) {
            imageView.setImageResource(R.drawable.abaixopeso);
        }
        else if (imcDouble >= 18.5 && imcDouble < 24.9) {
            imageView.setImageResource(R.drawable.normal);
        }
        else if (imcDouble >= 25 && imcDouble < 29.9) {
            imageView.setImageResource(R.drawable.sobrepeso);
        }
        else if (imcDouble >= 30 && imcDouble < 34.9) {
            imageView.setImageResource(R.drawable.obesidade1);
        }
        else if (imcDouble >= 35 && imcDouble < 39.9) {
            imageView.setImageResource(R.drawable.obesidade2);
        }
        else {
            imageView.setImageResource(R.drawable.obesidade3);
        }
    }
}